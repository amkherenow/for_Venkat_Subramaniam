package editdistance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class EditDistanceTest {
  private EditDistance editDistance;

  @BeforeEach
  void init() {
    editDistance = new EditDistance();
  }

  @Test
  void alignStreak(){
    assertAll(
      () -> assertEquals(List.of(new WordPair("pal", "pal", false)),
                        editDistance.computeOptimalWordPairs("pal", "pal")),
      () -> assertEquals(List.of(new WordPair("l", "g", false), new WordPair("ist", "ist", false)),
                        editDistance.computeOptimalWordPairs("list", "gist")),
      () -> assertEquals(List.of(new WordPair("s", "g", false), new WordPair("lid", "lid", false), new WordPair("ing", "e", false)),
                        editDistance.computeOptimalWordPairs("sliding", "glide")),
      () -> assertEquals(List.of(new WordPair("m", "bl", false), new WordPair("ist", "ist", false)),
                        editDistance.computeOptimalWordPairs("mist", "blist")),
      () -> assertEquals(List.of(new WordPair("cru", "be", false), new WordPair("nch", "nch", false)),
                        editDistance.computeOptimalWordPairs("crunch", "bench")),
      () -> assertEquals(List.of(new WordPair("t", "p", false), new WordPair("or", "or", false), new WordPair("ch", "t", false)),
                        editDistance.computeOptimalWordPairs("torch", "port")),
      () -> assertEquals(List.of(new WordPair("p", "", false), new WordPair("it", "it", false)),
                        editDistance.computeOptimalWordPairs("pit", "it")),
      () -> assertEquals(List.of(new WordPair("hello", "hello", false)),
                        editDistance.computeOptimalWordPairs("hello", "hello")),
      () -> assertEquals(List.of(new WordPair("p", "b", false), new WordPair("at", "at", false)),
                        editDistance.computeOptimalWordPairs("pat", "bat")),
      () -> assertEquals(List.of(new WordPair("p", "p", false), new WordPair("a", "u", false), new WordPair("t", "t", false)),
                        editDistance.computeOptimalWordPairs("pat", "put")),
      () -> assertEquals(List.of(new WordPair("", "t", false), new WordPair("he", "he", false), new WordPair("llo", "re", false)),
                        editDistance.computeOptimalWordPairs("hello", "there")),
      () -> assertEquals(List.of(new WordPair("ski", "", false), new WordPair("p", "p", false), new WordPair("", "urge", false)),
                        editDistance.computeOptimalWordPairs("skip", "purge")),
      () -> assertEquals(List.of(new WordPair("att", "kuch", false), new WordPair("i", "i", false), new WordPair("vil", "bhot", false), new WordPair("l", "l", false), new WordPair("i", "a", false)),
                        editDistance.computeOptimalWordPairs("attivilli", "kuchibhotla"))
    );
  }

  @Test
  void matchingStrings(){
    var result = editDistance.compute("hello", "hello");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "hello", "hello"));

    assertEquals(List.of(), result);
  }

  @Test
  void startLetterDifferent(){
    var result = editDistance.compute("pat", "bat");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pat", "bat"));

    assertEquals(List.of("REPLACE : bat"), result);
  }

  @Test
  void secondLetterDifferent(){
    var result = editDistance.compute("pat", "put");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pat", "put"));

    assertEquals(List.of("REPLACE : put"), result);
  }

  @Test
  void extraFirstCharacter(){
    var result = editDistance.compute("pit", "it");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pit", "it"));

    assertEquals(List.of(" DELETE : it"), result);
  }

  @Test
  void soundToand(){
    var result = editDistance.compute("sound", "and");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "sound", "and"));

    var expected = List.of(
        "REPLACE : aound",
        " DELETE : aund",
        " DELETE : and"
    );

    assertEquals(expected, result);
  }

  @Test
  void helloToThere(){
    var result = editDistance.compute("hello", "there");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "hello", "there"));

    var expected = List.of(
        "    ADD : thello",
        "REPLACE : therlo",
        "REPLACE : thereo",
        " DELETE : there"
    );

    assertEquals(expected, result);
  }

  @Test
  void brandTogrand(){
    var result = editDistance.compute("brand", "grand");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "brand", "grand"));

    var expected = List.of(
        "REPLACE : grand"
    );

    assertEquals(expected, result);
  }

  @Test
  void powerToshower(){
    var result = editDistance.compute("power", "shower");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "power", "shower"));

    var expected = List.of(
        "REPLACE : sower",
        "    ADD : shower"
    );

    assertEquals(expected, result);
  }

  @Test
  void grindToshrink(){
    var result = editDistance.compute("grind", "shrink");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "grind", "shrink"));

    var expected = List.of(
        "REPLACE : srind",
        "    ADD : shrind",
        "REPLACE : shrink"
    );

    assertEquals(expected, result);
  }

  @Test
  void bunkTodrunk(){
    var result = editDistance.compute("bunk", "drunk");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "bunk", "drunk"));

    var expected = List.of(
        "REPLACE : dunk",
        "    ADD : drunk"
    );

    assertEquals(expected, result);
  }

  @Test
  void moneyTomonkey(){
    var result = editDistance.compute("money", "monkey");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "money", "monkey"));

    var expected = List.of(
        "    ADD : monkey"
    );

    assertEquals(expected, result);
  }

  @Test
  void solidTosplendid(){
    var result = editDistance.compute("solid", "splendid");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "solid", "splendid"));

    var expected = List.of(
      "REPLACE : splid",
      "    ADD : spleid",
      "    ADD : splenid",
      "    ADD : splendid"
    );

    assertEquals(expected, result);
  }

  @Test
  void skipTopurge(){
    var result = editDistance.compute("skip", "purge");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "skip", "purge"));

    var expected = List.of(
      "REPLACE : pkip",
      "REPLACE : puip",
      "REPLACE : purp",
      "REPLACE : purg",
      "    ADD : purge"
    );

    assertEquals(expected, result);
  }

  @Test
  void attivilliTokuchibhotla(){
    var result = editDistance.compute("attivilli", "kuchibhotla");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "attivilli", "kuchibhotla"));

    var expected = List.of(
      "REPLACE : kttivilli",
      "REPLACE : kutivilli",
      "REPLACE : kucivilli",
      "    ADD : kuchivilli",
      "REPLACE : kuchibilli",
      "REPLACE : kuchibhlli",
      "REPLACE : kuchibholi",
      "    ADD : kuchibhotli",
      "REPLACE : kuchibhotla"
    );

    assertEquals(expected, result);
  }
}
