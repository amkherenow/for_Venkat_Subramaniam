package editdistance;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class EditDistance
{
    private enum Action {ADD, DELETE, REPLACE}; 

    private record SubStringInfo(int word1Index, int word2Index, int subStringLength, int transitionsCount) {}

    private static final SubStringInfo DEFAULT_SUB_STRING_INFO = new SubStringInfo(-1, -1, -1, 1 << 30);

    public List<String> compute(final String word1, final String word2) {
        final List<WordPair> optimalWordPairs = computeOptimalWordPairs(word1, word2);
        final List<String> transitions = computeTransitions(word1, word2, optimalWordPairs);
        return transitions;
    }

    public List<WordPair> computeOptimalWordPairs(final String word1, final String word2) {
        final WordPair wordPair = new WordPair(word1, word2, true);
        List<WordPair> inputWordPairs = null;
        List<WordPair> outputWordPairs = Arrays.asList(wordPair);

        while (!outputWordPairs.equals(inputWordPairs)) {
            inputWordPairs = outputWordPairs;
            outputWordPairs = transformIntoOptimalWordPairs(inputWordPairs);
        }

        return outputWordPairs;
    }

    private List<WordPair> transformIntoOptimalWordPairs(final List<WordPair> wordPairs) {
        final List<WordPair> outputWordPairs = new ArrayList<>();

        for (final WordPair wordPair : wordPairs) {
            if (wordPair.isSplittingFeasible()) {
                final List<WordPair> optimalWordPairs = splitWordPairOptimally(wordPair);
                outputWordPairs.addAll(optimalWordPairs);
            } else {
                outputWordPairs.add(wordPair);
            }
        }

        return outputWordPairs;
    }

    private List<WordPair> splitWordPairOptimally(final WordPair wordPair) {
        final List<SubStringInfo> word1SubStrings = getAllSubStrings(wordPair.word1());
        final List<SubStringInfo> listOfSubStringInfo = new ArrayList<>();

        for (final SubStringInfo word1SubStringInfo : word1SubStrings) {
            final SubStringInfo wordPairSubStringInfo = findOptimalSubStringInfoForWord1SubString(word1SubStringInfo, wordPair);

            if (wordPairSubStringInfo != null)
                listOfSubStringInfo.add(wordPairSubStringInfo);
        }

        final SubStringInfo optimalSubStringInfo = findOptimalSubStringInfoForWordPair(listOfSubStringInfo);

        return constructOptimalWordPairs(optimalSubStringInfo, wordPair);
    }

    private List<SubStringInfo> getAllSubStrings(final String word1) {
        final int minSubStringLength = 1;
        final int maxSubStringLength = word1.length();
        final List<SubStringInfo> word1SubStrings = new ArrayList<>();

        for (int subStringLength = minSubStringLength; subStringLength <= maxSubStringLength; subStringLength++) {
            final int minSubStringStartIndex = 0;
            final int maxSubStringStartIndex = word1.length() - subStringLength;

            for (int startIndex = minSubStringStartIndex; startIndex <= maxSubStringStartIndex; startIndex++) {
                final SubStringInfo word1SubStringInfo = new SubStringInfo(startIndex, -1, subStringLength, -1);
                word1SubStrings.add(word1SubStringInfo);
            }
        }

        return word1SubStrings;
    }

    private SubStringInfo findOptimalSubStringInfoForWord1SubString(final SubStringInfo word1SubStringInfo, final WordPair wordPair) {
        final int subStringLength = word1SubStringInfo.subStringLength();
        final int word1StartIndex = word1SubStringInfo.word1Index();
        final String word1SubString = wordPair.word1().substring(word1StartIndex, word1StartIndex + subStringLength);

        final int minStartIndex = 0;
        final int maxStartIndex = wordPair.word2().length() - subStringLength;

        int minTransitionsCount = 1 << 30;
        int optimalWord2StartIndex = -1;

        for (int startIndex = minStartIndex; startIndex <= maxStartIndex; startIndex++) {
            final String word2SubString = wordPair.word2().substring(startIndex, startIndex + subStringLength);

            if (!word2SubString.equals(word1SubString))
                continue;

            final int transitionsCount = computeTransitionsCountFromSubStringInfo(word1SubStringInfo, wordPair, startIndex);

            if (transitionsCount >= minTransitionsCount)
                continue;

            minTransitionsCount = transitionsCount;
            optimalWord2StartIndex = startIndex;
        }

        if (minTransitionsCount == 1 << 30)
            return null;
        else
            return new SubStringInfo(word1StartIndex, optimalWord2StartIndex, subStringLength, minTransitionsCount);
    }

    private int computeTransitionsCountFromSubStringInfo(final SubStringInfo word1SubStringInfo, final WordPair wordPair, final int word2StartIndex) {
        final int word1StartIndex = word1SubStringInfo.word1Index();
        final int subStringLength = word1SubStringInfo.subStringLength();

        final int firstWordPairTransitionsCount = Math.max(word1StartIndex, word2StartIndex);
        final int lastWordPairTransitionsCount = Math.max(
            wordPair.word1().length() - word1StartIndex - subStringLength,
            wordPair.word2().length() - word2StartIndex - subStringLength);

        return firstWordPairTransitionsCount + lastWordPairTransitionsCount;
    }

    private SubStringInfo findOptimalSubStringInfoForWordPair(final List<SubStringInfo> listOfSubStringInfo) {
        SubStringInfo optimalSubStringInfo = new SubStringInfo(-1, -1, -1, 1 << 30);

        for (final SubStringInfo subStringInfo : listOfSubStringInfo) {
            if (subStringInfo.transitionsCount() < optimalSubStringInfo.transitionsCount())
                optimalSubStringInfo = subStringInfo;
        }

        return optimalSubStringInfo;
    }

    private List<WordPair> constructOptimalWordPairs(final SubStringInfo subStringInfo, final WordPair wordPair) {
        if (subStringInfo.equals(DEFAULT_SUB_STRING_INFO))
            return List.of(new WordPair(wordPair.word1(), wordPair.word2(), false));

        final int word1Index = subStringInfo.word1Index();
        final int word2Index = subStringInfo.word2Index();
        final int subStringLength = subStringInfo.subStringLength();

        String word1SubString = wordPair.word1().substring(0, word1Index);
        String word2SubString = wordPair.word2().substring(0, word2Index);
        boolean isSplittingFeasible = word1SubString.equals("") || word2SubString.equals("")
            ? false : true;
        final WordPair firstWordPair = new WordPair(word1SubString, word2SubString, isSplittingFeasible);

        final List<WordPair> wordPairs = new ArrayList<>();
        if (!isEmpty(firstWordPair))
            wordPairs.add(firstWordPair);

        final String subString = wordPair.word1().substring(word1Index, word1Index + subStringLength);
        final WordPair middleWordPair = new WordPair(subString, subString, false);
        wordPairs.add(middleWordPair);

        word1SubString = wordPair.word1().substring(word1Index + subStringLength);
        word2SubString = wordPair.word2().substring(word2Index + subStringLength);
        isSplittingFeasible = word1SubString.equals("") || word2SubString.equals("")
            ? false : true;
        final WordPair lastWordPair = new WordPair(word1SubString, word2SubString, isSplittingFeasible);
        if (!isEmpty(lastWordPair))
            wordPairs.add(lastWordPair);

        return wordPairs;
    }

    private boolean isEmpty(final WordPair wordPair) {
        return wordPair.word1().isEmpty() && wordPair.word2().isEmpty();
    }

    private List<String> computeTransitions(final String word1, final String word2, final List<WordPair> optimalWordPairs) {
        if (isBruteForceTransitionsOptimal(word1, word2, optimalWordPairs))
            return computeTransitionsFromOptimalWordPairs(List.of(new WordPair(word1, word2, false)), true);

        return computeTransitionsFromOptimalWordPairs(optimalWordPairs, false);
    }

    private boolean isBruteForceTransitionsOptimal(final String word1, final String word2, final List<WordPair> optimalWordPairs) {
        final int bruteForceTransitionsCount = Math.max(word1.length(), word2.length());

        final int optimalWordPairsTransitionsCount = computeTransitionsCountFromWordPairs(optimalWordPairs);

        return bruteForceTransitionsCount <= optimalWordPairsTransitionsCount;
    }

    private int computeTransitionsCountFromWordPairs(final List<WordPair> wordPairs) {
        int transitionsCount = 0;

        for (final WordPair wordPair : wordPairs) {
            if (wordPair.word1().equals(wordPair.word2()))
                continue;

            transitionsCount += Math.max(wordPair.word1().length(), wordPair.word2().length());
        }

        return transitionsCount;
    }

    private List<String> computeTransitionsFromOptimalWordPairs(final List<WordPair> optimalWordPairs, final boolean isBruteForce) {
        final List<String> transitions = new ArrayList<>();

        for (int wordPairIndex = 0; wordPairIndex < optimalWordPairs.size(); wordPairIndex++) {
            final List<String> nextTransitions = buildNextTransitions(optimalWordPairs, isBruteForce, wordPairIndex);

            if (nextTransitions != null)
                transitions.addAll(nextTransitions);
        }
    
        return transitions;
    }

    private List<String> buildNextTransitions(final List<WordPair> optimalWordPairs, final boolean isBruteForce,
            final int currentWordPairIndex) {

        final WordPair currentWordPair = optimalWordPairs.get(currentWordPairIndex);
        final String word1 = currentWordPair.word1();
        final String word2 = currentWordPair.word2();

        if (word1.equals(word2))
            return null;

        final int maxWordLength = Math.max(word1.length(), word2.length());
        final String formatString = String.format("%%-%ds", maxWordLength);
        final String paddedWord1 = String.format(formatString, word1);
        final String paddedWord2 = String.format(formatString, word2);

        String completedTransition = "";
        if (!isBruteForce) {
            for (int wordPairIndex = 0; wordPairIndex < currentWordPairIndex; wordPairIndex++) {
                final WordPair wordPair = optimalWordPairs.get(wordPairIndex);
                completedTransition += wordPair.word2();
            }
        }

        String pendingTransition = "";
        if (!isBruteForce) {
            for (int wordPairIndex = currentWordPairIndex + 1; wordPairIndex < optimalWordPairs.size(); wordPairIndex++) {
                final WordPair wordPair = optimalWordPairs.get(wordPairIndex);
                pendingTransition += wordPair.word1();
            }
        }

        final List<String> transitions = new ArrayList<>();

        for (int wordIndex = 0; wordIndex < maxWordLength; wordIndex++) {
            final char word1Char = paddedWord1.charAt(wordIndex);
            final char word2Char = paddedWord2.charAt(wordIndex);

            final Action action = word1Char == ' '
                ? Action.ADD : word2Char == ' '
                    ? Action.DELETE : Action.REPLACE;

            final String currentTransition =
                paddedWord2.substring(0, wordIndex + 1).replaceAll(" ", "") +
                paddedWord1.substring(wordIndex + 1).replaceAll(" ", "");

            String transition = completedTransition + currentTransition + pendingTransition;

            transition = String.format("%7s : %s", action, transition);
            transitions.add(transition);
        }

        return transitions;
    }

    public boolean isTransitionsCountNotMoreThanMaxWordLength(final List<String> transitions, final String word1, final String word2) {
        final int maxWordLength = Math.max(word1.length(), word2.length());

        return transitions.size() <= maxWordLength;
    }

    private static void printTransitions(final List<String> transitions, final String word1, final String word2) {
        System.out.printf("\n%s -> %s\n", word1, word2);
        System.out.printf("Edit Distance = %d\n", transitions.size());

        for (String transition : transitions)
            System.out.println(transition);
    }

    public static void main(String[] args) {
        EditDistance editDistance = new EditDistance();

        printTransitions(editDistance.compute("pqqrst",      "qqttps"),"pqqrst",      "qqttps");
        printTransitions(editDistance.compute("qqttps",      "pqqrst"),"qqttps",      "pqqrst");
        printTransitions(editDistance.compute("attivilli",   "kuchibhotla"),"attivilli",   "kuchibhotla");
        printTransitions(editDistance.compute("kuchibhotla", "attivilli"),"kuchibhotla", "attivilli");
        printTransitions(editDistance.compute("hello",       "there"),"hello",       "there");
        printTransitions(editDistance.compute("there",       "hello"),"there",       "hello");
        printTransitions(editDistance.compute("money",       "monkey"),"money",       "monkey");
        printTransitions(editDistance.compute("monkey",      "money"),"monkey",      "money");
        printTransitions(editDistance.compute("skip",        "purge"),"skip",        "purge");
        printTransitions(editDistance.compute("purge",       "skip"),"purge",       "skip");
        printTransitions(editDistance.compute("bounce",      "ounce"),"bounce",      "ounce");
        printTransitions(editDistance.compute("ounce",       "bounce"),"ounce",       "bounce");
        printTransitions(editDistance.compute("movva",       "gutta"),"movva",       "gutta");
        printTransitions(editDistance.compute("gutta",       "movva"),"gutta",       "movva");
        printTransitions(editDistance.compute("abcd",        "abab"),"abcd",        "abab");
        printTransitions(editDistance.compute("abab",        "abcd"),"abab",        "abcd");
        printTransitions(editDistance.compute("abcd",        "aabb"),"abcd",        "aabb");
        printTransitions(editDistance.compute("aabb",        "abcd"),"aabb",        "abcd");
        printTransitions(editDistance.compute("kitten",      "sitting"),"kitten",      "sitting");
        printTransitions(editDistance.compute("sitting",     "kitten"),"sitting",     "kitten");
    }
}