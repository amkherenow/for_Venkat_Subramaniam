package editdistance;

public record WordPair(String word1, String word2, boolean isSplittingFeasible) {}