package editdistance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static editdistance.Action.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import static editdistance.WordPair.getNewWordPair;
import static editdistance.WordPairGroup.getNewWordPairGroup;

public class EditDistanceTest {
  private EditDistance editDistance;

  @BeforeEach
  void init() {
    editDistance = new EditDistance();
  }

  @Test
  void alignStreak(){
    assertAll(
      () -> assertEquals(List.of(new WordPair("pal", "pal", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("pal", "pal")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("l", "g", true), new WordPair("ist", "ist", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("list", "gist")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("s", "g", true), new WordPair("lid", "lid", true), new WordPair("ing", "e", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("sliding", "glide")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("m", "bl", true), new WordPair("ist", "ist", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("mist", "blist")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("cru", "be", true), new WordPair("nch", "nch", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("crunch", "bench")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("t", "p", true), new WordPair("or", "or", true), new WordPair("ch", "t", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("torch", "port")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("p", "", true), new WordPair("it", "it", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("pit", "it")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("hello", "hello", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("hello", "hello")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("p", "b", true), new WordPair("at", "at", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("pat", "bat")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("p", "p", true), new WordPair("a", "u", true), new WordPair("t", "t", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("pat", "put")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("", "t", true), new WordPair("he", "he", true), new WordPair("llo", "re", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("hello", "there")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("ski", "", true), new WordPair("p", "p", true), new WordPair("", "urge", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("skip", "purge")))).wordPairs()),
      () -> assertEquals(List.of(new WordPair("att", "kuch", true), new WordPair("i", "i", true), new WordPair("vil", "bhot", true), new WordPair("l", "l", true), new WordPair("i", "a", true)),
                        editDistance.splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair("attivilli", "kuchibhotla")))).wordPairs())
    );
  }

  @Test
  void matchingStrings(){
    var result = editDistance.compute("hello", "hello");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "hello", "hello"));

    assertEquals(List.of(), result);
  }

  @Test
  void startLetterDifferent(){
    var result = editDistance.compute("pat", "bat");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pat", "bat"));

    assertEquals(List.of(new Transition(REPLACE, "bat")), result);
  }

  @Test
  void secondLetterDifferent(){
    var result = editDistance.compute("pat", "put");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pat", "put"));

    assertEquals(List.of(new Transition(REPLACE, "put")), result);
  }

  @Test
  void extraFirstCharacter(){
    var result = editDistance.compute("pit", "it");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "pit", "it"));

    assertEquals(List.of(new Transition(DELETE, "it")), result);
  }

  @Test
  void soundToand(){
    var result = editDistance.compute("sound", "and");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "sound", "and"));

    var expected = List.of(
        new Transition(REPLACE, "aound"),
        new Transition(DELETE, "aund"),
        new Transition(DELETE, "and")
    );

    assertEquals(expected, result);
  }

  @Test
  void helloToThere(){
    var result = editDistance.compute("hello", "there");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "hello", "there"));

    var expected = List.of(
        new Transition(ADD, "thello"),
        new Transition(REPLACE, "therlo"),
        new Transition(REPLACE, "thereo"),
        new Transition(DELETE, "there")
    );

    assertEquals(expected, result);
  }

  @Test
  void brandTogrand(){
    var result = editDistance.compute("brand", "grand");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "brand", "grand"));

    var expected = List.of(
        new Transition(REPLACE, "grand")
    );

    assertEquals(expected, result);
  }

  @Test
  void powerToshower(){
    var result = editDistance.compute("power", "shower");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "power", "shower"));

    var expected = List.of(
        new Transition(REPLACE, "sower"),
        new Transition(ADD, "shower")
    );

    assertEquals(expected, result);
  }

  @Test
  void grindToshrink(){
    var result = editDistance.compute("grind", "shrink");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "grind", "shrink"));

    var expected = List.of(
        new Transition(REPLACE, "srind"),
        new Transition(ADD, "shrind"),
        new Transition(REPLACE, "shrink")
    );

    assertEquals(expected, result);
  }

  @Test
  void bunkTodrunk(){
    var result = editDistance.compute("bunk", "drunk");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "bunk", "drunk"));

    var expected = List.of(
        new Transition(REPLACE, "dunk"),
        new Transition(ADD, "drunk")
    );

    assertEquals(expected, result);
  }

  @Test
  void moneyTomonkey(){
    var result = editDistance.compute("money", "monkey");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "money", "monkey"));

    var expected = List.of(
        new Transition(ADD, "monkey")
    );

    assertEquals(expected, result);
  }

  @Test
  void solidTosplendid(){
    var result = editDistance.compute("solid", "splendid");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "solid", "splendid"));

    var expected = List.of(
      new Transition(REPLACE, "splid"),
      new Transition(ADD, "spleid"),
      new Transition(ADD, "splenid"),
      new Transition(ADD, "splendid")
    );

    assertEquals(expected, result);
  }

  @Test
  void skipTopurge(){
    var result = editDistance.compute("skip", "purge");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "skip", "purge"));

    var expected = List.of(
      new Transition(REPLACE, "pkip"),
      new Transition(REPLACE, "puip"),
      new Transition(REPLACE, "purp"),
      new Transition(REPLACE, "purg"),
      new Transition(ADD, "purge")
    );

    assertEquals(expected, result);
  }

  @Test
  void attivilliTokuchibhotla(){
    var result = editDistance.compute("attivilli", "kuchibhotla");

    assertTrue(editDistance.isTransitionsCountNotMoreThanMaxWordLength(result, "attivilli", "kuchibhotla"));

    var expected = List.of(
      new Transition(REPLACE, "kttivilli"),
      new Transition(REPLACE, "kutivilli"),
      new Transition(REPLACE, "kucivilli"),
      new Transition(ADD, "kuchivilli"),
      new Transition(REPLACE, "kuchibilli"),
      new Transition(REPLACE, "kuchibhlli"),
      new Transition(REPLACE, "kuchibholi"),
      new Transition(ADD, "kuchibhotli"),
      new Transition(REPLACE, "kuchibhotla")
    );

    assertEquals(expected, result);
  }
}
