package editdistance;

import static editdistance.WordPair.getNewWordPair;
import static editdistance.WordPairGroup.getNewWordPairGroup;
import static editdistance.SubStringInfo.getNewSubStringInfo;

import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.function.BinaryOperator;
import java.util.Optional;
import java.util.List;

public class EditDistance
{
    public List<Transition> compute(final String word1, final String word2) {
        System.out.printf("\n%s -> %s\n", word1, word2);

        final List<WordPair> optimalWordPairs
            = splitIntoOptimalWordPairGroup(getNewWordPairGroup(List.of(getNewWordPair(word1, word2)))).wordPairs();

        if (isWordPairGroupOptimalThanBruteForce(optimalWordPairs, word1, word2))
            return computeOptimalTransitionsFromWordPairGroup(optimalWordPairs, false);
        else
            return computeOptimalTransitionsViaBruteForce(word1, word2);
    }

    public WordPairGroup splitIntoOptimalWordPairGroup(final WordPairGroup wordPairGroup) {
        return Stream.iterate(wordPairGroup, this::splitIntoNextOptimalWordPairGroup)
            .filter(WordPairGroup::isNoMoreSplittingFeasible)
            .findFirst()
            .orElseThrow();
    }

    private WordPairGroup splitIntoNextOptimalWordPairGroup(final WordPairGroup wordPairGroup) {
        final List<WordPair> optimalWordPairs = wordPairGroup.wordPairs().stream()
            .flatMap(this::splitIntoOptimalWordPairs)
            .toList();

        return new WordPairGroup(optimalWordPairs, wordPairGroup.wordPairs().equals(optimalWordPairs));
    }

    private Stream<WordPair> splitIntoOptimalWordPairs(final WordPair wordPair) {
        if (wordPair.isNoMoreSplittingFeasible())
            return Stream.of(wordPair);

        final Optional<SubStringInfo> optimalSubStringInfo = findOptimalSubStringInfo(wordPair);

        return generateOptimalWordPairStream(wordPair, optimalSubStringInfo);
    }

    private Optional<SubStringInfo> findOptimalSubStringInfo(final WordPair wordPair) {
        return IntStream.iterate(wordPair.word1().length(), word1Length -> word1Length > 0, word1Length -> word1Length - 1)
            .boxed()
            .flatMap(subStringLength -> IntStream.rangeClosed(0, wordPair.word1().length() - subStringLength)
                .mapToObj(word1Index -> createSubStringInfoFor(word1Index, subStringLength, wordPair)))
            .filter(subStringInfo -> wordPair.word2().contains(subStringInfo.subString()))
            .map(subStringInfo -> findOptimalWord2IndexFor(subStringInfo, wordPair))
            .collect(Collectors.reducing(BinaryOperator.minBy(Comparator.comparing(SubStringInfo::transitionsCount))));
    }

    private SubStringInfo createSubStringInfoFor(final int word1Index, final int subStringLength, final WordPair wordPair) {
        return getNewSubStringInfo(word1Index, wordPair.word1().substring(word1Index, word1Index + subStringLength));
    }

    private SubStringInfo findOptimalWord2IndexFor(final SubStringInfo subStringInfo, final WordPair wordPair) {
        return IntStream.rangeClosed(0, wordPair.word2().length() - subStringInfo.subString().length())
            .filter(word2Index -> doesSubStringExistAt(word2Index, subStringInfo, wordPair))
            .mapToObj(word2Index -> computeTransitionsCountFor(word2Index, subStringInfo, wordPair))
            .collect(Collectors.reducing(BinaryOperator.minBy(Comparator.comparing(SubStringInfo::transitionsCount))))
            .orElseThrow();
    }

    private boolean doesSubStringExistAt(final int word2Index, final SubStringInfo subStringInfo, final WordPair wordPair) {
        return wordPair.word2()
            .substring(word2Index, word2Index + subStringInfo.subString().length())
            .equals(subStringInfo.subString());
    }

    private SubStringInfo computeTransitionsCountFor(final int word2Index,
            final SubStringInfo subStringInfo, final WordPair wordPair) {
        final WordPair firstWordPair = getNewWordPair(wordPair.word1().substring(0, subStringInfo.word1Index()),
            wordPair.word2().substring(0, word2Index));

        final WordPair lastWordPair =
            getNewWordPair(wordPair.word1().substring(subStringInfo.word1Index() + subStringInfo.subString().length()),
                wordPair.word2().substring(word2Index + subStringInfo.subString().length()));

        final int firstWordPairTransitionsCount = Math.max(firstWordPair.word1().length(), firstWordPair.word2().length());

        final int lastWordPairTransitionsCount = Math.max(lastWordPair.word1().length(), lastWordPair.word2().length());

        final int transitionsCount = firstWordPairTransitionsCount + lastWordPairTransitionsCount;

        return new SubStringInfo(subStringInfo.word1Index(), word2Index, subStringInfo.subString(), transitionsCount);
    }

    private Stream<WordPair> generateOptimalWordPairStream(final WordPair wordPair,
            final Optional<SubStringInfo> optimalSubStringInfo) {
        return optimalSubStringInfo.map(subStringInfo -> List.of(
                    createFirstWordPair(subStringInfo, wordPair),
                    new WordPair(subStringInfo.subString(), subStringInfo.subString(), true),
                    createLastWordPair(subStringInfo, wordPair)
                ).stream()
                .filter(pairOfWords -> (pairOfWords.word1().length() != 0) || (pairOfWords.word2().length() != 0))
            ).orElse(Stream.of(new WordPair(wordPair.word1(), wordPair.word2(), true)));
    }

    private WordPair createFirstWordPair(final SubStringInfo subStringInfo, final WordPair wordPair) {
        final String word1 = wordPair.word1().substring(0, subStringInfo.word1Index());

        final String word2 = wordPair.word2().substring(0, subStringInfo.word2Index());

        final boolean isNoMoreSplittingFeasible = (word1.length() == 0) || (word2.length() == 0);

        return new WordPair(word1, word2, isNoMoreSplittingFeasible);
    }

    private WordPair createLastWordPair(final SubStringInfo subStringInfo, final WordPair wordPair) {
        final String word1 = wordPair.word1().substring(subStringInfo.word1Index() + subStringInfo.subString().length());

        final String word2 = wordPair.word2().substring(subStringInfo.word2Index() + subStringInfo.subString().length());

        final boolean isNoMoreSplittingFeasible = (word1.length() == 0) || (word2.length() == 0);

        return new WordPair(word1, word2, isNoMoreSplittingFeasible);
    }

    private boolean isWordPairGroupOptimalThanBruteForce(final List<WordPair> optimalWordPairs, final String word1, final String word2) {
        final int wordPairGroupTransitionsCount = countTransitionsInWordPairGroup(optimalWordPairs);

        final int bruteForceTransitionsCount = Math.max(word1.length(), word2.length());

        return wordPairGroupTransitionsCount < bruteForceTransitionsCount;
    }

    private int countTransitionsInWordPairGroup(final List<WordPair> optimalWordPairs) {
        return optimalWordPairs.stream()
            .filter(this::isThisNotCommonSubStringWordPair)
            .mapToInt(this::computeWordPairTransitionsCount)
            .sum();
    }

    private boolean isThisNotCommonSubStringWordPair(final WordPair wordPair) {
        return !wordPair.word1().equals(wordPair.word2());
    }

    private int computeWordPairTransitionsCount(final WordPair wordPair) {
        return Math.max(wordPair.word1().length(), wordPair.word2().length());
    }

    private List<Transition> computeOptimalTransitionsFromWordPairGroup(final List<WordPair> optimalWordPairs, final boolean isBruteForce) {
        return IntStream.range(0, optimalWordPairs.size())
            .filter(wordPairIndex -> isThisNotCommonSubStringWordPair(optimalWordPairs.get(wordPairIndex)))
            .boxed()
            .flatMap(wordPairIndex -> computeOptimalTransitionsFromWordPair(wordPairIndex, optimalWordPairs, isBruteForce))
            .toList();
    }

    private Stream<Transition> computeOptimalTransitionsFromWordPair(final int wordPairIndex,
            final List<WordPair> optimalWordPairs, final boolean isBruteForce) {
        final WordPair currentWordPair = optimalWordPairs.get(wordPairIndex);

        final int maxWordLength = Math.max(currentWordPair.word1().length(), currentWordPair.word2().length());
        final String formatString = String.format("%%-%ds", maxWordLength);

        final String paddedWord1 = String.format(formatString, currentWordPair.word1());
        final String paddedWord2 = String.format(formatString, currentWordPair.word2());

        final String alreadyTransitionedSubString =
            isBruteForce ? "" : IntStream.range(0, wordPairIndex)
                .mapToObj(optimalWordPairs::get)
                .map(WordPair::word2)
                .collect(Collectors.joining(""));

        final String yetToBeTransitionedSubString =
            isBruteForce ? "" : IntStream.range(wordPairIndex + 1, optimalWordPairs.size())
                .mapToObj(optimalWordPairs::get)
                .map(WordPair::word1)
                .collect(Collectors.joining(""));

        return IntStream.range(0, maxWordLength)
            .mapToObj(wordIndex -> createTransitionFor(wordIndex, paddedWord1, paddedWord2))
            .map(transition -> updateTransition(transition, alreadyTransitionedSubString, yetToBeTransitionedSubString));
    }

    private Transition createTransitionFor(final int wordIndex, final String word1, final String word2) {
        final Action action = findActionFor(wordIndex, word1, word2);

        final String transitioningSubStringFromWord1 = word1.substring(wordIndex + 1).replaceAll(" ", "");
        final String transitioningSubStringFromWord2 =
            word2.substring(0, wordIndex + 1)
                .replaceAll(" ", "");

        final String transitioningSubString = transitioningSubStringFromWord2 + transitioningSubStringFromWord1;

        return new Transition(action, transitioningSubString);
    }

    private Action findActionFor(final int wordPairIndex, final String word1, final String word2) {
        return word1.charAt(wordPairIndex) == ' '
            ? Action.ADD : word2.charAt(wordPairIndex) == ' '
                ? Action.DELETE : Action.REPLACE;
    }

    private Transition updateTransition(final Transition transition,
            final String alreadyTransitionedString, final String yetToBeTransitionedString) {
        return new Transition(transition.action(), alreadyTransitionedString + transition.someTransitionOfWord1() + yetToBeTransitionedString);
    }

    private List<Transition> computeOptimalTransitionsViaBruteForce(final String word1, final String word2) {
        return computeOptimalTransitionsFromWordPairGroup(List.of(getNewWordPair(word1, word2)), true);
    }

    public static void printTransitions(final List<Transition> transitions) {
        System.out.printf("Optimal # of transitions = %d\n", transitions.size());

        transitions.stream()
            .map(EditDistance::buildPrintableStringFor)
            .forEach(System.out::println);
    }

    private static String buildPrintableStringFor(final Transition transition) {
        return String.format("%7s :: %s", transition.action(), transition.someTransitionOfWord1());
    }

    public boolean isTransitionsCountNotMoreThanMaxWordLength(final List<Transition> transitions, final String word1, final String word2) {
        final int bruteForceTransitionsCount = Math.max(word1.length(), word2.length());

        return transitions.size() <= bruteForceTransitionsCount;
    }

    public static void main(String[] args) {
        EditDistance editDistance = new EditDistance();

        printTransitions(editDistance.compute("pqqrst",      "qqttps"));
        printTransitions(editDistance.compute("qqttps",      "pqqrst"));
        printTransitions(editDistance.compute("attivilli",   "kuchibhotla"));
        printTransitions(editDistance.compute("kuchibhotla", "attivilli"));
        printTransitions(editDistance.compute("hello",       "there"));
        printTransitions(editDistance.compute("there",       "hello"));
        printTransitions(editDistance.compute("money",       "monkey"));
        printTransitions(editDistance.compute("monkey",      "money"));
        printTransitions(editDistance.compute("skip",        "purge"));
        printTransitions(editDistance.compute("purge",       "skip"));
        printTransitions(editDistance.compute("bounce",      "ounce"));
        printTransitions(editDistance.compute("ounce",       "bounce"));
        printTransitions(editDistance.compute("movva",       "gutta"));
        printTransitions(editDistance.compute("gutta",       "movva"));
        printTransitions(editDistance.compute("abcd",        "abab"));
        printTransitions(editDistance.compute("abab",        "abcd"));
        printTransitions(editDistance.compute("abcd",        "aabb"));
        printTransitions(editDistance.compute("aabb",        "abcd"));
        printTransitions(editDistance.compute("kitten",      "sitting"));
        printTransitions(editDistance.compute("sitting",     "kitten"));
        printTransitions(editDistance.compute("sound",     "and"));
    }
}
