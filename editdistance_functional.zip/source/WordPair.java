package editdistance;

public record WordPair(String word1, String word2, boolean isNoMoreSplittingFeasible) {
    public static WordPair getNewWordPair(final String word1, final String word2) {
        return new WordPair(word1, word2, false);
    }
}
