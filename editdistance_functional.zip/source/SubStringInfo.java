package editdistance;

public record SubStringInfo(int word1Index, int word2Index, String subString, int transitionsCount) {
    public static SubStringInfo getNewSubStringInfo(int word1Index, String subString) {
        return new SubStringInfo(word1Index, -1, subString, -1);
    }
}