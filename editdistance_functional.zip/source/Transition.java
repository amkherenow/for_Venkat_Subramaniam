package editdistance;

public record Transition(Action action, String someTransitionOfWord1) {}