package editdistance;

public enum Action {ADD, DELETE, REPLACE, NONE};