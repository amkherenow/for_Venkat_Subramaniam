package editdistance;

import java.util.List;

public record WordPairGroup(List<WordPair> wordPairs, boolean isNoMoreSplittingFeasible) {
    public static WordPairGroup getNewWordPairGroup(final List<WordPair> wordPairs) {
        return new WordPairGroup(wordPairs, false);
    }
}
